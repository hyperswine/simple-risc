{-# LANGUAGE DataKinds, TypeApplications, TypeOperators, FlexibleContexts, RecordWildCards, NoImplicitPrelude, NumericUnderscores, CPP, DeriveGeneric, DeriveAnyClass #-}
{-# OPTIONS_GHC -Wno-missing-export-lists #-}
module SdramPipeline where
import Clash.Prelude
import Data.Maybe (isJust,isNothing)
import qualified SimpleRisc as R

decodeTarget :: R.Word32 -> R.MemoryTarget
decodeTarget address
  | address .&. 0xff80_0000 == 0x8000_0000 = R.RamTarget
  | address >= R.ioBase && address <= R.ioBase + 12 = R.IoTarget
  | address .&. 0xffff_f000 == R.ioBase = R.UnmappedTarget
  | otherwise = R.decodeMemoryTarget address

-- A fixed-latency cache port lets the existing pipeline overlap instructions
-- on hits. The port answers four logical clocks after its request (the cache
-- registers its BSRAM read return), so this image also uses the pipeline's
-- deeper in-flight fetch queue and the one-cycle-longer load wait. On misses
-- every logical CPU/memory stage freezes together; cycle counters, physical
-- UART and refresh continue to run on physical clocks.
initialMachine :: R.Machine
initialMachine = R.boardMachine {R.cpuExternalMemory=True,
#ifdef RISCV_COMPRESSED
  R.cpuCompressed=True
#else
  R.cpuCompressed=False
#endif
  }

type Address = Unsigned 22
type Input = (R.Word32,Bool,Maybe R.Byte,Bool,Bool,R.Word32,R.Word32,Maybe R.Word32,Vec 4 (Signed 34))
type Output = (Address,Bool,R.Word32,BitVector 4,Maybe R.Byte)

physical :: R.Word32 -> Address
physical address
  | address .&. 0xff80_0000 == 0x8000_0000 = resize (address `shiftR` 2) .&. 0x1f_ffff
  | R.romAddress address = 0x20_0000 .|. resize ((address `shiftR` 2) .&. 0x1ff)
  | otherwise = 0x20_0000 -- idle/device accesses never reach external RAM

-- The fast port's full address and byte lanes are already registers in
-- Machine. They are captured on the same edge as the old cache a0 stage.
-- Keep only the other request fields here, then look up those registers
-- directly. In particular no reset/next-Machine mux drives the cache address.
-- The cache owns the remaining logical stages, including the register after
-- its BSRAM read, so the CPU sees a four-logical-clock port. A hold freezes
-- this slot with the cache stages.
data RequestSlot = RequestSlot
  { slotBusActive :: Bool, slotBusAddress :: R.Word32, slotFast :: Bool,
    slotWrite :: Bool, slotData :: R.Word32 }
  deriving (Generic,NFDataX,Show,Eq)

initialRequestSlot :: RequestSlot
initialRequestSlot = RequestSlot False 0 False False 0

requestSlot :: R.Machine -> Output -> RequestSlot
requestSlot machine (_,writing,value,_,_) = RequestSlot active busAddress (R.cpuFast machine) writing value
 where
 bus=R.systemBus machine
 active=case R.busPhase bus of R.BusIdle -> isJust (R.cpuBusRequest machine); _ -> True
 busAddress=R.busAddress (R.busRequest bus)

requestAddress :: R.Machine -> RequestSlot -> Address
requestAddress machine RequestSlot{..} = physical selected
 where
 selected
   | slotBusActive = slotBusAddress
   | slotWrite = R.cpuPortWriteAddressFull machine
   | slotFast = R.cpuPortAddressFull machine
   | otherwise = 0

requestMask :: R.Machine -> RequestSlot -> BitVector 4
requestMask machine slot
  | slotBusActive slot || not (slotWrite slot) = 15
  | otherwise = R.cpuPortByteEnable machine

-- A hold no longer selects the whole machine's next state. The step always
-- runs; the circuit registers 'HeldState' (counters and the received byte)
-- unconditionally, the pipeline stages under their own per-stage enables, and
-- the rest of 'Machine' under a hold-aware enable, so a held cycle simply
-- does not load those registers and the outputs are idled.
step :: R.Machine -> Input -> (R.Machine,Output,R.StagePayloads,R.StageLoad)
step machine (memoryWord,held,received,txReady,emergency,a,b,ioAnswer,products) =
  let injected=machine {R.cpuRfA=a,R.cpuRfB=b,R.cpuMulProducts=products,R.cpuDevices=(R.cpuDevices machine) {R.devIo=ioAnswer}}
      (next,(index,write,tx),stages,loads)=R.machineStepCoreStagesBy R.pipelinedCpuStepStages decodeTarget injected (memoryWord,received,txReady,emergency)
      bus=R.systemBus machine
      busActive=case R.busPhase bus of R.BusIdle -> isJust (R.cpuBusRequest machine); _ -> True
      busAddress=R.busAddress (R.busRequest bus)
      readAddress
        | busActive = busAddress
        | R.cpuFast machine = R.cpuPortAddressFull next
        | otherwise = 0
      writeAddress=if busActive then busAddress else R.cpuPortWriteAddressFull next
      mask=if busActive then 15 else R.cpuPortByteEnable next
      output=case write of
        Just (_,value) -> (physical writeAddress,True,value,mask,tx)
        Nothing -> (physical readAddress,False,0,15,tx)
   in ( next {R.cpuRegs=repeat 0,R.cpuMulOperandsMirror=(0,0,0),R.cpuMulProductsMirror=repeat 0}
      , if held then (0x20_0000,False,0,15,Nothing) else output
      , stages
      , loads )


-- Only the SPI byte port is exposed. The BRAM image's DMA engine has a
-- 64 KiB second RAM port and cannot address SDRAM, so its registers stay
-- unmapped here. An answer survives a cache hold until the CPU can take it;
-- the physical SPI shifter keeps running while the CPU is frozen.
data SpiIo = SpiIo {slotSpi :: R.Spi, slotAnswer :: Maybe R.Word32}
  deriving (Generic,NFDataX,Show,Eq)

initialSpiIo :: SpiIo
initialSpiIo = SpiIo R.initialSpi Nothing

spiIoStep :: SpiIo -> (Maybe R.BusRequest,Bool,Bool,Bit) ->
 (SpiIo,(Maybe R.Word32,(Bit,Bit,Bit)))
spiIoStep io (request,reset,held,miso) = (next,(slotAnswer io,R.spiPins (slotSpi io)))
 where
 spi=(slotSpi io) {R.spiMiso=miso}
 taken=if held || isJust (slotAnswer io) then Nothing else request
 offset=maybe 0 (\q -> R.busAddress q .&. 0xfff) taken
 writing at=case taken of
   Just q | R.busWrite q && offset==at -> Just (R.busData q)
   _ -> Nothing
 value
   | offset==R.ioSpiData = resize (R.spiIn spi)
   | offset==R.ioSpiStatus = R.boolWord (R.spiBusy spi)
   | offset==R.ioSpiControl = R.boolWord (R.spiSelect spi) .|. (resize (R.spiDivider spi) `shiftL` 8)
   | offset==12 = 0x5344_5031 -- SDP1: SPI-only SDRAM peripheral version 1
   | otherwise = 0
 answer
   | held = slotAnswer io
   | otherwise = (\q -> if R.busWrite q then 0 else value) <$> taken
 next
   | reset = initialSpiIo
   | otherwise = SpiIo (R.stepSpi (resize <$> writing R.ioSpiData) (writing R.ioSpiControl) spi) answer

{-# ANN topEntity (Synthesize {t_name="sdram_pipeline_risc",
 t_inputs=[PortName "clk",PortName "reset",PortName "enable",PortName "uart_rx",PortName "memory_data",PortName "memory_hold",PortName "sd_miso"],
 t_output=PortProduct "" [PortName "uart_tx",PortName "memory_address",PortName "memory_write",PortName "memory_wdata",PortName "memory_mask",PortName "sd_sck",PortName "sd_mosi",PortName "sd_cs"]}) #-}
topEntity :: Clock XilinxSystem -> Reset XilinxSystem -> Enable XilinxSystem ->
 Signal XilinxSystem Bit -> Signal XilinxSystem R.Word32 -> Signal XilinxSystem Bool -> Signal XilinxSystem Bit ->
 (Signal XilinxSystem Bit,Signal XilinxSystem Address,Signal XilinxSystem Bool,Signal XilinxSystem R.Word32,Signal XilinxSystem (BitVector 4),Signal XilinxSystem Bit,Signal XilinxSystem Bit,Signal XilinxSystem Bit)
topEntity clk rst en rx dat held miso = withClockResetEnable clk rst en (circuit rx dat held miso)

circuit :: HiddenClockResetEnable dom => Signal dom Bit -> Signal dom R.Word32 -> Signal dom Bool -> Signal dom Bit ->
 (Signal dom Bit,Signal dom Address,Signal dom Bool,Signal dom R.Word32,Signal dom (BitVector 4),Signal dom Bit,Signal dom Bit,Signal dom Bit)
circuit serialRx memoryData memoryHeld sdMiso = fst (circuitWithObservations serialRx memoryData memoryHeld sdMiso)

type BoardOutput dom = (Signal dom Bit,Signal dom Address,Signal dom Bool,Signal dom R.Word32,Signal dom (BitVector 4),Signal dom Bit,Signal dom Bit,Signal dom Bit)

-- The production top selects only the first component, so synthesis removes
-- the observation cone. The observed top is a functional simulation target;
-- it must never supply a board timing/resource measurement.
circuitWithObservations :: HiddenClockResetEnable dom => Signal dom Bit -> Signal dom R.Word32 -> Signal dom Bool -> Signal dom Bit ->
 (BoardOutput dom, Signal dom R.PipelineTrace)
circuitWithObservations serialRx memoryData memoryHeld sdMiso = ((serialTx,address,write,wdata,mask,sck,mosi,cs),trace)
 where
 trace=R.pipeTraceWith decodeTarget <$> running <*> memoryData
 receivedNow=R.uartRx (register high (register high serialRx))
 emergency=register False ((==Just 3) <$> receivedNow)
 -- A hold is a clock enable on the machine register, not a next-state select:
 -- the counters and the received-byte holding register load every cycle, and
 -- the rest loads unless the cache holds the core or Ctrl-C breaks it.
 stepped=step <$> running <*> bundle (memoryData,memoryHeld,received,txReady,emergency,rfA,rfB,ioAnswer,mulProducts)
 machineNext=(\(m,_,_,_) -> m) <$> stepped
 stageNext=(\(_,_,ps,_) -> ps) <$> stepped
 machineOutput=(\(_,o,_,_) -> o) <$> stepped
 holding=liftA2 (\held breakingNow -> held && not breakingNow) memoryHeld breaking
 machine=regEn initialMachine (not <$> holding) machineNext
 -- One clock-enabled register per pipeline stage. They all load on the same
 -- hold enable: gating a stage group on its own advance decision put the whole
 -- advance cone (a function of the frozen pipeline registers) in front of the
 -- hold enable that every one of the 5,000 pipeline flops also uses. Synthesis
 -- then merged the two nets, and the pipeline's clock enable inherited four
 -- levels of stage logic on top of its routing tree (2026-10-29). A stage that
 -- does not advance loads its own payload back.
 stageD=regEn (R.spD R.initialStagePayloads) (not <$> holding) ((\ps -> R.spD ps) <$> stageNext)
 stageE1=regEn (R.spE1 R.initialStagePayloads) (not <$> holding) ((\ps -> R.spE1 ps) <$> stageNext)
 stageE2=regEn (R.spE2 R.initialStagePayloads) (not <$> holding) ((\ps -> R.spE2 ps) <$> stageNext)
 stageM=regEn (R.spM R.initialStagePayloads) (not <$> holding) ((\ps -> R.spM ps) <$> stageNext)
 stages=R.StagePayloads <$> stageD <*> stageE1 <*> stageE2 <*> stageM
 heldState=register R.initialHeldState (R.heldStateOf <$> machineNext)
 -- The pipeline itself is the largest remaining field, so it gets its own
 -- register: the hold enable is the widest net in the design either way, and
 -- one 5,000-load enable was the critical path before the split.
 pipeState=regEn (R.cpuPipe initialMachine) (not <$> holding) (R.cpuPipe <$> machineNext)
 running=R.withStagePayloads <$> stages <*> (R.applyHeldState <$> heldState <*> (R.withPipe <$> pipeState <*> machine))
 -- Both the Ctrl-C reset and the hold clock-enable start at a register, not at
 -- the assembled pipeline: 'cpuInRom' only ever comes from the machine
 -- register, so reading it through 'running' put the enable that every
 -- pipeline flop shares behind record-select logic. 'heldRx' is the one field
 -- the held-state register supplies while the machine register is frozen.
 breaking=R.breakRequested <$> machine <*> emergency
 rxWanted=(\held offered headByte -> isNothing (R.heldRx held) && isNothing offered && isJust headByte) <$> heldState <*> received <*> rxHead
 rxPop=(&&) <$> rxWanted <*> (not <$> breaking)
 received=register Nothing (mux rxPop rxHead (pure Nothing))
 (rxHead,_)=unbundle (mealy R.fifoStep (R.initialFifo :: R.Fifo 32) (bundle (breaking,receivedNow,rxPop)))
 (serialTx,uartReady)=R.uartTx txOffer
 txPush=register Nothing txNow
 txPop=(\ready headByte -> ready && isJust headByte) <$> uartReady <*> txHead
 txOffer=mux txPop txHead (pure Nothing)
 (txHead,txCount)=unbundle (mealy R.fifoStep (R.initialFifo :: R.Fifo 16) (bundle (pure False,txPush,txPop)))
 txReady=register False ((<15) <$> txCount)
 rfWrite=(\m stop pause -> if stop || pause then Nothing else R.cpuPendingWrite m) <$> running <*> breaking <*> memoryHeld
 rfA=asyncRam (SNat @32) (fst . R.cpuReadIndices <$> running) rfWrite
 rfB=asyncRam (SNat @32) (snd . R.cpuReadIndices <$> running) rfWrite
 miso=register high (register high sdMiso)
 (ioAnswer,ioPins)=unbundle (mealy spiIoStep initialSpiIo
   (bundle (R.ioRequest <$> running,R.clearRegisters <$> running,memoryHeld,miso)))
 (sck,mosi,cs)=unbundle ioPins
 -- Free-running DSP operand and product registers: no enable, no reset
 -- mux, so the MULT18X18 input/output registers absorb them (R.cpuMulProducts).
 mulOperands=register (0,0,0) (R.multiplyOperands <$> running)
 mulProducts=register (repeat 0) (R.partialProductsOf <$> mulOperands)
 request=regEn initialRequestSlot (not <$> memoryHeld) (requestSlot <$> running <*> machineOutput)
 address=requestAddress <$> running <*> request
 write=slotWrite <$> request
 wdata=slotData <$> request
 mask=requestMask <$> running <*> request
 txNow=(\(_,_,_,_,tx) -> tx) <$> machineOutput
