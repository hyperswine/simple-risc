# Tang Nano 20K

Build and run the Clash designs on a Sipeed Tang Nano 20K (Gowin
GW2AR-LV18QN88C8/I7) with the open-source toolchain (oss-cad-suite: yosys,
nextpnr-himbaechel, gowin_pack, openFPGALoader).

| Design | Source | Build script | Clock |
|---|---|---|---|
| SimpleRisc (RV32IM, 64 KiB RAM) | `src/SimpleRisc.hs` | `build.sh`; verified with `build_gowin.sh` | PLL; the Gowin-verified build is 78 MHz (placement mode 2) |
| FP-RISC development preset (RV32IMC, 8 MiB SDRAM) | `src/SdramPipeline.hs` | `SDRAM_PRESET=fprisc-48 sdram/build.sh` | CPU/SDRAM 48/48 MHz; one-way 64 KiB cache; internal timing and physical workload evidence, SDRAM I/O qualification pending |
| SimpleRisc SDRAM pipeline (8 MiB, experimental) | `src/SdramPipeline.hs` | `sdram/build.sh pipeline` (Gowin) | Two-way 64 KiB default; historical one-way IMC 72/54 MHz [timing and regressions](../../docs/2026-10-19-TANGNANO20K-INTEGRATION.md), classifier 2.06 s and +0.008 ns internal setup margin; two-way and SDRAM I/O qualification pending |
| Earlier serial SDRAM core | `src/SdramSimpleRisc.hs` | `sdram/build.sh serial` (Gowin) | cached 66 MHz |
| PsramRegs | `src/PsramRegs.hs` | `build_psram.sh` | 27 MHz oscillator |

```bash
boards/tangnano20k/build.sh
```

```bash
boards/tangnano20k/build.sh load
```

`load` writes FPGA SRAM only; the design is gone after a power cycle. Set
`OSS_CAD_SUITE` if the suite is not at `~/Documents/Libs/oss-cad-suite`.

For FP-RISC examples, use `SDRAM_PRESET=fprisc-48 sdram/build.sh` from this
directory (or `SDRAM_PRESET=fprisc-48 boards/tangnano20k/sdram/build.sh` from
the repository root). It fixes the SDRAM pipeline at 48/48 MHz, RV32IMC,
64 KiB cache, 135-degree phase and placement 2, and records a build manifest.
The 72/54 MHz experiment in the table is not accepted for the larger repeated
GC classifier workload. See the sibling FP-RISC
[preset guide](../../../fprisc/docs/2026-10-21-TANGNANO20K-PRESET.md).

## Pins

From `tangnano20k.cst`: clock 4 (27 MHz), S1 button 88 (active high, resets
the core), UART RX 70 and UART TX 69 (both wired to the on-board BL616
USB bridge).

## Talking to the board

The BL616 shows up as two serial ports, for example on macOS:

| Port | Function |
|---|---|
| `/dev/cu.usbserial-XXXXXXXX0` | JTAG (used by openFPGALoader) |
| `/dev/cu.usbserial-XXXXXXXX1` | UART to the FPGA |

SimpleRisc's UART divider is 868 clocks per bit, so the baud rate follows the
core clock: `FREQ_MHZ * 1e6 / 868`. That is 115200 at 100 MHz but, for example,
110599 at the 96 MHz default, which standard terminals do not offer. On macOS
set an arbitrary rate by configuring the port with `tcsetattr` at a standard
rate and then calling the `IOSSIOSPEED` ioctl (`0x80085402`) with the exact
rate. Setting a non-standard speed through `tcsetattr` alone fails with
`EINVAL`.

## Boot ROM and memory map

| Address | Device |
|---|---|
| `0x0000_0000`–`0x0000_07ff` | boot ROM, 2 KiB (the reset vector; loads only, stores fault) |
| `0x0010_0000` | finisher (QEMU `virt` style: `0x5555` = exit 0, `code << 16 \| 0x3333` = exit `code`) |
| `0x0010_0004` | BOOTCAUSE, read-only; a read clears it: 0 none, 1 power-on, 2 Ctrl-C, 3 finisher exit |
| `0x0200_0000` | CLINT (QEMU `virt` layout): `msip` `+0x0`, `mtimecmp` `+0x4000`/`+0x4004`, `mtime` `+0xbff8`/`+0xbffc`; `mtime` counts core clocks |
| `0x0c00_0000` | PLIC (QEMU `virt` layout) with one source, the UART as IRQ 10: priority `+0x28`, pending `+0x1000`, enable `+0x2000`, threshold `+0x20_0000`, claim/complete `+0x20_0004` |
| `0x1000_0000`–`0x1000_000c` | UART: TXDATA, STATUS, RXDATA, CTRL (bit 0 receive interrupt, bit 1 transmit-ready interrupt) |
| `0x1000_1000`–`0x1000_1fff` | The I/O complex, outside the CPU (word accesses; one registered handshake each): SPI master for the microSD slot at `+0x000` DATA, `+0x004` STATUS (bit 0 busy), `+0x008` CTRL (bit 0 chip select, bits 8-15 half SCK period in clocks minus one); SPI DMA at `+0x100` ADDR, `+0x104` COUNT, `+0x108` CTRL (start: bit 0 send, bit 1 wait for the 0xfe token), `+0x10c` STATUS (bit 0 busy, bit 1 error, bits 8-15 token). `c/sd.c` is the SPI-mode card driver |
| `0x8000_0000`–`0x8000_ffff` | RAM, 64 KiB (8 MiB on the SDRAM image) |

Every other address raises an access fault, and fetching outside the ROM and
RAM raises an instruction access fault.

The CPU starts in the boot ROM (`bootrom/`, C plus a short `crt0.S`), which
implements the host protocol in software. The legacy commands retain their
framing; Base images use the extended load and readback commands, and `I`/`U`/
`C`/`G` add versioned identity and CRC-verified upload:

| Byte | Meaning |
|---|---|
| `P`, count (16-bit little endian), words | load up to 16,384 words at `0x8000_0000`, then a zero word after them |
| `R` | run from `0x8000_0000` with every register and the trap state cleared (`mret`) |
| `M` | clear the first 64 KiB of RAM |
| `X` | nothing: every run already starts from zeroed registers |
| `Q`, count (32-bit little endian), words | load up to 524,288 words (2 MiB) on SDRAM; the BRAM ROM bounds this at 16,320 words (64 KiB minus 256 bytes for its stack) |
| `V` | reread the last accepted upload from RAM, XOR its 32-bit words, send eight lowercase hex digits plus newline |
| `H` | alias for `R`, used by the Base uploader |
| `T` | send `DONE` as a UART probe |
| `I` | board identity, one line: `SRID1 isa=rv32imc cpu=00000030 mem=00000030 ram=00800000 max=00200000 cap=PMXQVHTUICG id=<16 hex>` |
| `U`, `"SRU1"`, count (32-bit), header CRC32, words, payload CRC32 | framed upload with bounded receive timeouts; replies `OK <crc32>` or `ERR HDR`/`LEN`/`TMO`/`CRC` |
| `C` | reread the last accepted upload from RAM, CRC32 its 32-bit words, send eight lowercase hex digits plus newline |
| `G` | run only after a complete verified upload, else `ERR NOIMG` |

See [the protocol record](../../docs/2026-10-28-ROM-IDENTITY-AND-VERIFIED-UPLOAD.md)
for the exact `U` framing, the error and resynchronisation behaviour, and what
`id=` does and does not identify: on an SDRAM build the ROM's metadata words are
re-stamped from every build input, so `id=` identifies the bitstream, not the
ROM. Starting any of `P`/`Q`/`U` invalidates the previous image, so a failed
upload cannot leave a stale image startable, and `ERR HDR`/`LEN`/`CRC` drain the
host's remaining bytes before replying so the link stays aligned.

`U` is implemented and passes the native ROM, host-library and simulator tests,
but it is **not qualified on hardware**: a 2026-10-28 probe returned `ERR HDR`
on one experimental image while its sibling accepted the identical frame.
`run_program.py` therefore still defaults to `--protocol p` (`P`+`R`), and
accepted physical results use legacy `Q`/`V`/`H`. Use `--identify` to query a
board without uploading, `--protocol u` for a CRC-verified upload and guarded
start, and `--manifest` to check a board's identity against a preset
`build-manifest.json`.

`Q` rejects an oversized frame without RAM writes, consumes its declared
payload, sends `ERR\n` and empties the readback range. A truncated load needs
a board reset. A zero count produces an empty range. Accepted nonempty
uploads append a zero sentinel when space remains within the command's
bound. `M` also empties the readback range. `P` retains its historical 64 KiB
limit and does not reserve loader stack space at that maximum.

The SDRAM build uses `bootrom-sdram.hex` and puts the ROM stack at
`0x8080_0000`; the BRAM build uses `bootrom.hex` and a stack at
`0x8001_0000`. Keeping the images separate prevents the BRAM core from
accepting SDRAM-sized writes. `bootrom/build.sh` rebuilds both committed
images. `bootrom/check_loader.py` runs both actual C parsers with native
UART/memory hooks, including the exact caps, oversized frames, corrupted
RAM readback, reset causes and legacy commands.
The [Base loader report](../../docs/2026-10-18-TANGNANO20K-BASE-LOADER.md) records the
implementation, verification and 48 MHz SDRAM build.

A program ends by writing the finisher, which resets the CPU into the ROM
with cause EXIT, or by taking a trap while `mtvec` is 0, which jumps to the
ROM at address 0. Either way the ROM sends "DONE" and waits for the next
command. Because of the zero word written after each image, a program that
runs off its end executes an illegal instruction, traps, and also ends with
"DONE". Power-on and Ctrl-C resets are silent. Resets keep RAM.

Ctrl-C (`0x03`) resets the CPU into the ROM only while a program is running.
Inside the ROM it is an ordinary byte, so images containing `0x03` (any load
whose destination register is even has it as its low byte) load intact.

The core embeds `bootrom/bootrom.hex` at compile time. After changing the ROM
source, rebuild it (gcc is needed only for this step) and commit the new
`bootrom.hex`:

```bash
boards/tangnano20k/bootrom/build.sh
```

## Running C programs

`c/` holds a minimal C runtime for SimpleRisc: `crt0.S` (sets `sp` and `gp`,
zeroes `.bss`, calls `main`, then writes the finisher at `0x00100000`;
the CPU resets into the boot ROM, which sends "DONE"), `link.ld` (64 KiB at
`0x8000_0000`, stack at the top) and a UART driver (`uart.h`, `uart.c`).
Programs build with `rv32im_zicsr/ilp32` support in `riscv64-unknown-elf-gcc`,
with no libc or libgcc. Exit preserves `mtvec`; installed guest trap handlers
cannot intercept the finisher. A program that ends with `ecall` and no trap
handler also ends with "DONE", through the ROM.

SimpleRisc supports the six Zicsr instructions, direct-mode machine traps,
`mret`, machine software, timer and external interrupts (taken between
instructions; external before software before timer), and a `wfi` that waits
until `mie & mip` is nonzero. The CLINT/PLIC/UART-control registers are
word-only. The boot ROM quietens all interrupt sources before each `R`, and
every reset does the same, but `mtime` keeps counting. `check_interrupts.py`
checks a WFI-driven periodic timer, priorities, the PLIC claim/complete
protocol and an interrupt-driven UART echo. The trap/status,
scratch and identification CSRs are available, together with writable 64-bit
`mcycle`/`minstret` counters and their read-only `cycle`/`instret` aliases.
Unknown CSRs and writes to read-only CSRs trap. See
[2026-10-05-TANGNANO20K-MACHINE-MODE.md](../../docs/2026-10-05-TANGNANO20K-MACHINE-MODE.md) for implementation
boundaries and measured board results. `check_traps.py` runs a guest C handler
that checks CSR operations, trap cause/PC/value and return status.
`check_counters.py` checks counter rollover, half writes, aliases, exact
retirement and faulting instructions that must not retire.
`check_finisher.py` verifies explicit success/failure exits with a nonzero
trap vector and an infinite loop after the store; see
[2026-10-05-TANGNANO20K-SYSTEM-BUS.md](../../docs/2026-10-05-TANGNANO20K-SYSTEM-BUS.md).
`check_bus.py --freq-mhz 96` checks mixed-width RAM traffic, signed UART RX
loads and single consumption through the registered data bus on three runs.

```bash
boards/tangnano20k/c/build.sh hello
```

```bash
boards/tangnano20k/run_program.py output/tangnano20k/c/hello.bin
```

`run_program.py` loads the image with the `P`/`R` host protocol, sends
`--input` text, and prints the output until "DONE". It keeps one port session
open throughout (see the bridge issue below); `--freq-mhz` sets the baud rate
for a non-default clock.

To run the same program in simulation instead, write the host byte stream to
a file and replay it through the core's real UART loader with `tb_program.v`:

```bash
boards/tangnano20k/run_program.py output/tangnano20k/c/hello.bin --frame /tmp/hello.hex
```

```bash
iverilog -o /tmp/tb.vvp boards/tangnano20k/tb_program.v output/tangnano20k/clash/SimpleRisc.topEntity/simple_risc.v
```

```bash
vvp -n /tmp/tb.vvp +frame=/tmp/hello.hex
```

Loading runs at UART speed, and iverilog simulates the current core at
roughly 3,000 clocks per second, so even the 30-byte `tb_simple_risc.v`
program takes about a minute and a 750-byte image about 40 minutes. `build.sh` writes the Verilog; to generate only the Verilog, run
`cabal run clash -- src/SimpleRisc.hs --verilog -outputdir output/tangnano20k/clash`.

## Architecture tests

`arch-tests/run_arch_tests.py` runs riscv-arch-test 3.9.1 under RISCOF with
Spike as the reference. It runs on Verilator models of four images (SDRAM
and BRAM pipelines, each with and without RVC) and writes
`output/arch-tests/results.md`. It needs RISCOF in `~/.cache/riscof-venv`
(or `RISCOF=...`), `spike`, `riscv64-unknown-elf-gcc` and Verilator, and
takes about 11 minutes including Clash. Results on 2026-10-19:

| image | tests | pass | fail | too big for 64 KiB |
|---|---:|---:|---:|---:|
| SDRAM pipeline with RVC | 92 | 92 | 0 | 0 |
| SDRAM pipeline | 63 | 63 | 0 | 0 |
| BRAM pipeline with RVC | 92 | 85 | 0 | 7 |
| BRAM pipeline | 63 | 56 | 0 | 7 |

Deliberate choices the tests accept: misaligned loads, stores and targets
trap rather than being emulated, and the core runs in machine mode only.
See [the report](../../docs/2026-10-19-TANGNANO20K-ARCH-TESTS.md) for the per-test table and what
it does not cover.

## Clock speed: nextpnr is optimistic

nextpnr's timing model for Gowin parts is only an estimate, and it has been
consistently optimistic for this design. The board is the only reliable
judge:

| Design | nextpnr fmax | Works on the board | Failures / limits |
|---|---|---|---|
| 1 cycle per instruction (early version) | 52 MHz | 27 MHz | 51 MHz |
| 2 cycles per instruction | 63 MHz | 51 MHz | not tested higher |
| 5 cycles per instruction (previous; retested 2026-10-05) | ~126 MHz | 51 MHz | 96 MHz |
| 8 cycles per instruction (earlier 2026-10-05) | 149.08 MHz, seed 2 | 96 MHz with the earlier suite; expanded ALU test passes at 51 MHz | expanded ALU test fails at 96, 102 and 108 MHz |
| 8 cycles ordinary / 9 cycles shifts (clock sweep, 2026-10-05) | 150.58 MHz, seed 2 | 108 and 114 MHz | 117 MHz: incorrect sieve; 120 MHz: subtraction failure |
| machine traps, Zicsr and split counters (2026-10-05) | 147.19 MHz, seed 2, route target 144 MHz | 96 MHz: counter, trap, CPU, RV32IM and FP-RISC suites | seed 1 at target 115.2 MHz loses string characters at 96 MHz despite a reported 142.90 MHz maximum |
| finisher and registered device target (2026-10-05) | 144.61 MHz, seed 3, route target 144 MHz | 96 MHz: finisher, counter, trap, CPU, RV32IM and FP-RISC suites | seed 2 misses the route margin target at 137.84 MHz; not loaded |
| registered data bus (2026-10-05) | 144.61 MHz, seed 7, route target 144 MHz | 96 MHz: bus, finisher, counter, trap, CPU, RV32IM and FP-RISC suites | seeds 3, 2, 1, 4, 5 and 6 miss the margin; not loaded |
| boot ROM, RAM at `0x8000_0000` (2026-10-11) | Gowin 96.480 MHz (vendor flow) | 96 MHz: every CPU suite plus FP-RISC; see [the report](../../docs/2026-10-11-TANGNANO20K-BOOT-ROM.md) | not tested higher |

`build.sh` therefore places and routes for `FREQ_MHZ * MARGIN`
(`MARGIN=1.5` by default, seed 3 tried first). To test above what timing allows, build with
`ALLOW_FAIL=1 MARGIN=1` and check on the board.

The paths that turned out to be slow on the real chip, well beyond what
nextpnr reported, were long carry chains, the 32-way register-file mux
(Gowin's `MUX2_LUT5`–`MUX2_LUT8` cells), and logic driving the block RAM
directly. `src/SimpleRisc.hs` now uses one-hot CPU stages, two-stage register
reads (four banks of eight), registered writeback, registered RAM commands and
readback, separate load/store alignment registers, and a queued UART request.
The iterative multiply/divide unit registers its 33-bit arithmetic before
committing each step. The barrel shifter now registers its result after the first two shift levels
and finishes the remaining three levels in a separate stage. Ordinary
instructions take nine clocks, shifts take ten; nonzero-divisor
M operations add 68 unit clocks. These changes trade cycles for shorter paths.

Run the hardware regressions after loading a bitstream:

```bash
python3 boards/tangnano20k/check_rv32i.py --freq-mhz 114 --repeat 10
python3 boards/tangnano20k/check_processor.py --freq-mhz 114
python3 boards/tangnano20k/check_rv32m.py --freq-mhz 114 --repeat 20
```

The ALU test checks all ten RV32I register operations, every shift distance,
signed edge cases and randomized operands against Python references (38,400
comparisons across ten loads). The processor test checks five exact C arithmetic
runs, UART echo, Ctrl-C recovery,
memory clear/reload, and 64 passes of byte/halfword/word memory checks. The
second compares all eight RV32M operations with host-generated results for
192 operand pairs per load, including division by zero and signed overflow.
Both keep the UART session open and stop the CPU before closing it.

Verified on 2026-10-05: both hardware commands passed at 96 MHz, including
30,720 RV32M checks across 20 loads. The FP-RISC Tang Nano builtin suite also
passed three smoke runs, seven refusal cases, and recovery on this bitstream.
`stack test --fast` and the generated-Verilog `HiDONE` UART test passed. An
earlier full-suite run exposed an intermittent failure in the unchanged
`test/PsramRegs.hs` snapshot-model property; the processor properties passed
on that run too. The verified SRAM image SHA-256 is
`2563be842bfbabcaf77c6a0e784feff27fc3077d2a28d2b01a4f423ecf51211e`.

The 96 MHz result above is historical coverage, not a pass of the expanded
ALU regression. The clock sweep found shift corruption at 96 MHz on that
image and corrected it with the registered shifter. See
[2026-10-05-TANGNANO20K-CLOCK-SWEEP.md](../../docs/2026-10-05-TANGNANO20K-CLOCK-SWEEP.md) for the current
114 MHz validation, failed higher clocks, bitstream hashes and replay commands.
The build and host-tool defaults remain 96 MHz; use an explicit `--freq-mhz`
matching the image loaded into the board.

## Known issue: the USB-UART bridge stops working

After some runs the UART port stops returning any data and only unplugging
the board brings it back.

### Symptoms

- The UART port opens normally but never returns a byte, even for a design
  that previously passed every test (for example at 27 MHz).
- Loading a new bitstream does not help.
- The JTAG side keeps working: `openFPGALoader --detect` still finds the
  GW2A and loading still succeeds.
- Unplugging and replugging the board fixes it immediately.

### Cause: reopening the port while the FPGA is sending

**Closing and reopening the UART port while the FPGA is transmitting wedges
the bridge.** It was reproduced on purpose with a SimpleRisc program that
transmits nonstop (`sw` to TXDATA in a loop) at about 110.6k baud:

| Run | Result |
|---|---|
| 3 min flood, port open and read throughout (2 MB at full line rate), then the port closed mid-stream and reopened about 0.1 s later to send Ctrl-C | wedged |
| 5 s flood, port open and read throughout, Ctrl-C sent in the same session | fine: the flood stopped and the next test passed |
| Flood, port closed mid-stream, reopened 5 s later to send Ctrl-C | wedged: the Ctrl-C never reached the FPGA, so the flood kept going, and then all traffic stopped |
| Flood, line settings and baud rate reapplied mid-stream (`tcsetattr` + `IOSSIOSPEED`), port kept open | fine |
| Flood, buffers flushed mid-stream (`tcflush`), port kept open | fine |
| Flood, port closed mid-stream and reopened without changing any settings | wedged |

So data volume is not the trigger, and neither is a long time with nobody
reading: the first run's only gap was about 0.1 s, but it included a
close and reopen. Changing the baud rate or flushing while data arrives is
harmless. The trigger is the close and reopen itself. After the reopen, the
host-to-FPGA direction dies first, and FPGA-to-host traffic stops shortly
after. The JTAG side is a separate USB interface and keeps working. A stuck
macOS driver seems unlikely, because the JTAG port uses the same driver and
was unaffected.

Which part of the close/open sequence the BL616 firmware mishandles is not
known. On macOS, closing the port normally drops the DTR/RTS handshake
lines, and reopening it resets the port to defaults (it read back as
9600 baud).

This also explains the wedges during overclocking sweeps: the test script
opened and closed the port for every test, and a CPU failing at too high a
clock was stuck re-sending one byte (`YNNNN...`), so the next test's open
hit a live stream.

### How to avoid it

- Never close or reopen the UART port while the FPGA may be sending. Stop the
  stream first, from the same open session: send Ctrl-C (`0x03`, which resets
  SimpleRisc's CPU), wait until no more bytes arrive, then close. Changing
  the baud rate within a session is fine.
- Better, keep one session open for a whole test run instead of reopening
  the port per test.
- Before reopening after a failure, load a harmless bitstream first. A
  reload stops the FPGA sending, and reopening after a reload has been
  tested to work. It cannot undo a wedge that already happened, though.
- For long overclocking sweeps, use a separate USB-serial adapter on spare
  FPGA pins instead of the BL616.

### Checking the setup

When a test suddenly returns nothing at all, check the setup before blaming
the design: build the design for 27 MHz, which is known to pass, and run it.
If that also returns nothing, the bridge is stuck; replug the board.

## Gowin vendor analysis

`boards/tangnano20k/build_gowin.sh` runs the licensed macOS vendor flow
without programming the board. The default is 96 MHz; select another PLL
clock with `FREQ_MHZ` (an integer multiple of 3). Reports and the SRAM image
are written to `output/tangnano20k/gowin-$FREQ_MHZ/impl/pnr/`.
`GOWIN_OUT` overrides the output directory and `GOWIN_PLACE_OPTION` selects
vendor placement mode 0 through 4 (default 0).

```bash
FREQ_MHZ=108 boards/tangnano20k/build_gowin.sh
```

The current verified SimpleRisc build runs ordinary instructions in a
pipeline and the rest in the multi-cycle phases
([2026-10-12-TANGNANO20K-PIPELINE.md](../../docs/2026-10-12-TANGNANO20K-PIPELINE.md)). It is:

```bash
GOWIN_PLACE_OPTION=2 FREQ_MHZ=78 boards/tangnano20k/build_gowin.sh
```

The UART then runs at 78,000,000 / 868 = 89,862 baud: pass `--freq-mhz 78`
to the check scripts. Placement modes give very different results with this
design (75-83 MHz at a 96 MHz target; a placement-3 image that met 78 MHz
failed PPP intermittently, see ../../docs/2026-10-12-TANGNANO20K-PIPELINE.md). The first pipeline, without
multiply, forwarding from execute or branch prediction, closed 96 MHz. The
phases alone, before the pipeline (commit bae9999), closed 117 MHz in mode 2
([2026-10-12-TANGNANO20K-MEMORY-PORT.md](../../docs/2026-10-12-TANGNANO20K-MEMORY-PORT.md)), and Gowin's license server refuses
builds intermittently; retry those.

The build checks the requested clock and rejects any internal setup or hold
violation. Gowin can generate a bitstream even when timing fails; the separate
`check_gowin_timing.py` guard makes that failure visible to callers.

The historical [vendor baseline](../../docs/2026-10-06-TANGNANO20K-GOWIN-TIMING.md) failed at
96 MHz (84.444 MHz maximum). The
[execution experiment](../../docs/2026-10-06-TANGNANO20K-EXECUTE-TIMING.md) records the staged ALU,
split comparisons, registered CSR selection, timing trials and board results.
Those measurements describe the earlier serial core; the current pipeline is
described above.

## SDRAM main-memory experiment

[The SDRAM report and build instructions](sdram/README.md) describe the
standalone full-capacity test and the separate processor image.
All 8 MiB passed 12,582,912 word comparisons. The earlier serial processor runs at 54 MHz,
or 66 MHz with its cache, with the same boot ROM and memory map as the BRAM
image except that RAM is all 8 MiB at `0x80000000`. C uses a 1 MiB working
set and FP-RISC uses a 2 MiB allocation on this image. Use `--freq-mhz 54`
(or 66) with the board tools. The boot ROM's `Q` command loads Base images of up to 2 MiB, and
`M` clears only the first 64 KiB. SRAM programming leaves flash unchanged.

The [new SDRAM pipeline](../../docs/2026-10-16-TANGNANO20K-SDRAM-PIPELINE.md) overlaps instructions
through a unified 2 KiB cache with 16-byte burst fills and four masked posted
writes. Its corrected IM image is board-tested at 54 MHz and optional C mode
at 27/48 MHz, including six FP-RISC stress programs. Its first board-loader
failure exposed a one-clock-late SDRAM burst capture and pin model. Four-beat
variants now use a 135-degree SDRAM clock. The report separates
physical results, timing candidates and remaining limits.
The [split-clock experiment](../../docs/2026-10-18-TANGNANO20K-SDRAM-CLOCKS.md) now passes vendor
timing and all 12 physical FP-RISC/SD cases at 72 MHz CPU / 54 MHz SDRAM.
The 108/54 MHz trial fails timing and compressed-instruction execution.
The new 72 MHz classifier takes 36.1% longer than the prior 48 MHz image;
the timing margin is only 3 ps. See the report for the remaining CPU paths,
the larger classifier's guest-heap limit and the SD file evidence.
The pipeline's [microSD SPI byte port](../../docs/2026-10-18-TANGNANO20K-SDRAM-SD-SPI.md) is mapped at
`0x10001000`, with capability `0x53445031` at `+0x0c`. SPI DMA remains limited
to the separate BRAM image.

## Separate RV64IM / Base host experiment

[rv64/README.md](rv64/README.md) describes the serial 64-bit variant verified at
27 MHz with cached 8 MiB SDRAM. It runs FP-RISC's experimental single-threaded
Base host with UART virtual devices and software floating point, including a
small guest in the existing WASM VM. Use its matching FPGA image and host
clock; the RV32 configurations documented above remain separate.
