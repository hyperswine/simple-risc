set_device -name GW2AR-18C GW2AR-LV18QN88C8/I7
set_option -output_base_name sdram_test
set_option -opt_goal timing
set_option -frequency 96
set_option -global_freq 96
set_option -map_option 3
set_option -route_option 1
set_option -route_maxfan 8
set_option -place_option 1
set_option -num_critical_paths 3000
add_file -type netlist "/Users/jasonqin/Documents/GitHub/simple-risc/output/tangnano20k/core-feedback-20261113/btb/p3/impl/gwsynthesis/sdram_test.vg"
add_file "/Users/jasonqin/Documents/GitHub/simple-risc/output/tangnano20k/core-feedback-20261113/btb/p1/pins.cst"
add_file "/Users/jasonqin/Documents/GitHub/simple-risc/output/tangnano20k/core-feedback-20261113/btb/p1/clocks.sdc"
run pnr
exit
